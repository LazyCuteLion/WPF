///<reference path="socket.js" />
///<reference path="common.js" />

Vue.component("media-player", {
    props: ["context"],
    template: `
        <div :data-ip='context.ip'>
            <template v-if="hasVideo">
                <div class="btn-default" @click="play">
                    播放
                </div>
                <div class="btn-default" @click="pause">
                    暂停
                </div>
                <div class="btn-default" @click="stop">
                    停止
                </div>
                <div>
                    音量
                    <input type="range" v-model.number="context.volume" @change="setVolume">
                    <span>
                        {{context.volume}}
                    </span>
                </div>
                <br>
                <div>
                    <span>
                        {{position_ts}}
                    </span>
                    <input type="range" v-model.number="context.position" :max="context.duration" 
                        style="width:600px;"
                        @change="setPosition"
                        @mousedown="stopProgress">
                    <span>
                        {{duration_ts}}
                    </span>
                </div>
            </template>
            <template v-else>
                <div>
                    音量
                    <input type="range" v-model.number="context.volume" @change="setVolume">
                    <span>
                        {{context.volume}}
                    </span>
                </div>
            </template>
        </div>
        `,
    computed: {
        hasVideo: function () {
            return this.context.videos != undefined && Array.isArray(this.context.videos);
        },
        position_ts: function () {
            if (this.context.position != undefined)
                return this.context.position.toTimeSpan();
        },
        duration_ts: function () {
            if (this.context.duration != undefined)
                return this.context.duration.toTimeSpan();
        }
    },
    methods: {
        play() {
            managers.computer.play(this.context);
        },
        pause() {
            managers.computer.pause(this.context);
        },
        stop() {
            managers.computer.stop(this.context);
        },
        setVolume() {
            managers.computer.setVolume(this.context);
        },
        setPosition() {
            managers.computer.setPosition(this.context);
        },
        stopProgress() {
            if (this.context.progress != undefined && this.context.progress > 0) {
                clearInterval(this.context.progress);
                this.context.progress = -1;
            }
        }
    }
});

Vue.component("my-dialog", {
    template: '\
        <transition name="fade">\
            <div v-show="visible" class="dialog">\
                <div>\
                    <div class="dialog-header">\
                        <slot name="header">{{title}}</slot>\
                        <a @click="close">关闭</a>\
                    </div>\
                    <div class="dialog-container">\
                        <slot></slot>\
                    </div>\
                </div>\
            </div>\
        </transition>\
    ',
    props: { context: Object, visible: Boolean, title: String },
    methods: {
        close: function () {
            this.$emit("update:visible", false);
        }
    }
});

Vue.component("pjlink", {
    props: ["context"],
    template: `
        <div :data-ip='context.ip'>
            <span>{{context.name}}-{{context.state}}</span>
            <input type="checkbox" v-model="context.state">
            <div class="btn-default" @click="on">
                开
            </div>
            <div class="btn-default" @click="off">
                关
            </div>
            <div class="btn-default" @click="refresh">
                刷新
            </div>
        </div>
        `,
    computed: {

    },
    methods: {
        on() {
            if (this.context.state == null) {
                alert("投影机正忙，请稍后重试！如果长时间未就绪，请点击[刷新]后重试！");
                return;
            }
            managers.pjlink.on(this.context);
            this.context.state = null;
        },
        off() {
            if (this.context.state == null) {
                alert("投影机正忙，请稍后重试！如果长时间未就绪，请点击[刷新]后重试！");
                return;
            }
            managers.pjlink.off(this.context);
            this.context.state = null;
        },
        refresh() {
            managers.pjlink.refresh(this.context);
        }
    }
});

//页面第一次加载不会响应[visibilitychange]（因为以下代码在页面加载后才运行）
//浏览器最小化/切换到后台时，停止播放器进度条动画
window.addEventListener("visibilitychange", function () {
    console.log("page:", document.visibilityState);
    if (document.visibilityState == "hidden") {
        //停止播放器进度条动画
        app.selection.mediaPlayers.forEach(f => {
            if (f.progress != undefined && f.progress > 0) {
                clearInterval(f.progress);
                f.progress = -1;
            }
        });
    }
    else if (document.visibilityState == "visible") {
        //重新获取视频播放进度
        if (app.openDialog) {
            app.selection.mediaPlayers.forEach(f => {
                managers.computer.getPosition(f);
            });
        }
    }
});


const app = new Vue({
    el: "#main",
    data: {
        selectedMenu: "",
        openDialog: false,
        menus: [],
        computers: [],
        projectors: [],
        jyboards: [],
        powerTimingDevices: []
    },
    created() {
        //获取数据
        // axios.get("data.json").then(function (res) {
        //     app.menus = res.data;
        // });

        //菜单
        this.menus = [{
            name: "",//菜单名称 [key]
            x: 0,//按钮坐标x
            y: 0//按钮坐标y
        }];

        //电脑主机(全部)
        this.computers = [{
            template: "computer",//主机模板
            menu: "",//所属菜单
            name: "", //名称
            ip: "127.0.0.1",//ip地址
            port: 1699,//端口 
            mac: "00-00-00-00-00-01",//网卡地址
            state: false,//电源状态
            online: false,//通信状态 可选
            volume: 0,//音量 包含该字段则表示需要控制该主机的音量
            videos: [],//视频列表 包含该字段则表示需要控制该主机的多媒体（包括音量）
            position: 0,//播放进度 可选
            duration: 66000 //视频时长 可选
        }];

        //投影机(全部)
        this.projectors = [{
            template: "pjlink",//投影机模板 pjlink协议
            menu: "",
            name: "投影机",
            ip: "127.0.0.1",
            port: 4352,
            state: null,
            online: false,
        }];

        //聚英继电器(全部)
        this.jyboards = [
            {
                template: "jyboard",
                ip: "127.0.0.1",//网络控制 没有该字段则表示串口控制
                port: 10000,//网络端口或串口号
                items: [{
                    template: "light|electrical|sanboard",//照明灯光、电器、沙盘灯光
                    name: "",
                    board: 1,//板卡地址（拨码）
                    no: 1,//开关号 
                    state: false,
                    menu: ""//所属菜单
                }]
            }
        ]

        //电源时序器
        this.powerTimingDevices = [
            {
                template: "power-timing-device",
                name: "",
                ip: "",
                port: ""
            }
        ]
    },
    mounted() {

        //主机状态
        managers.computer.addEventListener("state", function (e) {
            app.computers.forEach(f => {
                if (f.ip == e.ip) {
                    f.state = e.data;
                }
            });
            return true;
        });
        sockets.udp.addEventListener("exists", function (e) {
            const find = app.computers.find(f => f.ip == e.ip && f.port == e.port);
            if (find != undefined) {
                find.online = e.data;
            }
            return true;
        });
        //投影机电源状态
        managers.pjlink.addEventListener("state", function (e) {
            const find = app.projectors.find(f => f.ip == e.ip);
            if (find != undefined) {
                find.state = e.data;
            }
            return true;
        });
        //投影机网络状态
        sockets.tcp.addEventListener("exists", function (e) {
            const find = app.projectors.find(f => f.ip == e.ip);
            if (find != undefined) {
                find.online = e.data;
                if (!e.data) {
                    console.log(`%c投影机[${e.ip}]网络异常`, "color:red;");
                    console.logTime();
                }
            }
            return true;
        });

        //音量
        managers.computer.addEventListener("volume", function (e) {
            const find = app.selection.mediaPlayers.find(f => f.ip == e.ip);
            if (find != undefined) {
                app.$set(find, "volume", e.data);
            }
            return true;
        });
        //视频列表
        managers.computer.addEventListener("videos", function (e) {
            const find = app.selection.mediaPlayers.find(f => f.ip == e.ip);
            if (find != undefined) {
                app.$set(find, "videos", e.data);
            }
            return true;
        });
        //视频当前进度
        managers.computer.addEventListener("position", function (e) {
            if (!app.openDialog)
                return true;
            const find = app.selection.mediaPlayers.find(f => f.ip == e.ip);
            if (find != undefined && find.position != undefined) {
                //先停止当前进度条
                if (find.progress != undefined && find.progress > 0) {
                    clearInterval(find.progress);
                    find.progress = -1;
                }
                if (find.duration > e.data) {
                    if (e.data >= 0) {
                        find.position = e.data;
                        find.progress = setInterval(function () {
                            find.position += 100;
                            if (find.position >= find.duration) {
                                clearInterval(find.progress);
                                find.progress = -1;
                                find.position = find.duration;
                            }
                        }, 100);
                    }
                }
            }
            return true;
        });
        //视频时长
        managers.computer.addEventListener("duration", function (e) {
            const find = app.selection.mediaPlayers.find(f => f.ip == e.ip);
            if (find != undefined && find.duration != undefined) {
                //时长<=0,则表示停止
                if (e.data <= 0) {
                    if (find.progress != undefined && find.progress > 0) {
                        clearInterval(find.progress);
                        find.progress = -1;
                    }
                    find.position = 0;
                }
                else {
                    find.duration = e.data;
                }
            }
            return true;
        });

        //聚英继电器状态
        managers.jyboard.addEventListener("state", function (e) {
            const find = app.jyboards.find(f => f.port == e.port && f.ip == e.ip);
            if (find != undefined) {
                if (e.no == undefined && e.data.length > 1) {
                    const items = find.items.filter(t => t.board == e.board);
                    if (!convert.isNull(items)) {
                        items.forEach(item => {
                            if (item.no <= e.data.length) {
                                item.state = e.data[item.no - 1];
                            }
                        });
                    }
                }
                else {
                    const item = find.items.find(t => t.board == e.board && t.no == e.no);
                    if (item != undefined) {
                        item.state = e.data[0];
                    }
                }
                return true;
            }
        });
    },
    computed: {
        selection() {
            const menu = this.selectedMenu;

            let result = {
                computers: this.computers.filter(f => f.menu == menu),
                projectors: this.projectors.filter(f => f.menu == menu)
            };

            result.mediaPlayers = result.computers.filter(f => f.volume != undefined);

            for (let i = 0; i < this.jyboards.length; i++) {
                const jyboard = this.jyboards[i];
                for (let j = 0; j < jyboard.items.length; j++) {
                    const item = jyboard.items[j];
                    if (item.menu == menu) {
                        switch (item.template) {
                            case "light":
                                if (!result.lights || !Array.isArray(result.lights))
                                    result.lights = [];
                                result.lights.push(item);
                                break;
                            case "electrical":
                                if (!result.electricals || !Array.isArray(result.electricals))
                                    result.electricals = [];
                                result.electricals.push(item);
                                break;
                            case "sanboard":
                                if (!result.sanboards || !Array.isArray(result.sanboards))
                                    result.sanboards = [];
                                result.sanboards.push(item);
                                break;
                        }
                    }
                }
            }

            return result;
        },
        managers() {
            return managers;
        }
    },
    watch: {
        openDialog(v) {
            if (v) {
                //弹窗打开时：
                //查询主机状态/投影机状态/聚英继电器状态
                //查询播放器 volume,videos,position,duration
            }
            else {
                //弹窗关闭时：
                //停止进度条动画
                app.selection.mediaPlayers.forEach(f => {
                    if (f.progress != undefined && f.progress > 0) {
                        clearInterval(f.progress);
                        f.progress = -1;
                    }
                });
            }
        },
        selectedMenu(newValue, oldValue) {
            if (newValue != oldValue) {

            }
        }
    },
    methods: {
        open(menu) {
            if (this.openDialog)
                return;
            this.selectedMenu = menu;
            this.openDialog = true;
        },
        onAll() {
            if (confirm("将开启所有设备：主机、投影机、灯光等，确定操作？")) {

            }
        },
        offAll() {
            if (confirm("将关闭所有设备：主机、投影机、灯光等，一分钟后断电，确定操作？")) {

            }
        }
    }
});

var isDesign = false;
function design() {
    isDesign = true;
    let startX = 0;
    let startY = 0;
    let target = null;
    document.getElementById("main").onmousemove = function (e) {
        if (target != null) {
            const n = target.getAttribute("index");
            let moveX = e.clientX - startX;
            let moveY = e.clientY - startY;
            startX = e.clientX;
            startY = e.clientY;
            app.menus[n].x += moveX;
            app.menus[n].y += moveY;
        }
    };
    document.getElementById("main").onmouseup = function (e) {
        if (target != null) {
            const n = target.getAttribute("index");
            console.log("position:" + app.menus[n].x + "," + app.menus[n].y);
            target = null;
            e.stopPropagation();
            e.preventDefault();
        }
    };
    for (let i = 0; i < app.$refs.btn.length; i++) {
        const el = app.$refs.btn[i];
        el.setAttribute("index", i);
        el.onmousedown = function (e) {
            if (e.button == 0) {
                startX = e.clientX;
                startY = e.clientY;
                target = e.target;
            }
        };
    }
    return isDesign;
}