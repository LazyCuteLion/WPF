Vue.component("player", {
    props: { context: Object },
    template: '\
        <div>\
            <button v-if="isPlayer" @click="play">播放</button>\
            <button v-if="isPlayer" @click="pause">暂停</button>\
            <button v-if="isPlayer" @click="stop">停止</button>\
            <input type="range" style="width: 300px" v-if="context.volume>=0" v-model="context.volume" @change="volumeChange" ></input>\
        </div>\
        ',
    computed: {
        isPlayer: function () {
            return this.context.videos != undefined && Array.isArray(this.context.videos);
        }
    },
    methods: {
        play: function () {
            console.log("play:" + this.context.ip + ":" + this.context.port);
            udp.send(this.context.ip, this.context.port, "play");
        },
        pause: function () {
            console.log("pause:" + this.context.ip + ":" + this.context.port);
            udp.send(this.context.ip, this.context.port, "pause");
        },
        stop: function () {
            console.log("stop:" + this.context.ip + ":" + this.context.port);
            udp.send(this.context.ip, this.context.port, "stop");
        },
        volumeChange: function (event) {
            console.log("volume:" + this.context.volume);
            udp.send(this.context.ip, this.context.port, "volume=" + this.context.volume);
        }
    }
});



Vue.component("my-dialog", {
    template: '\
        <transition name="fade">\
            <div v-show="visible" class="dialog">\
                <div>\
                    <div class="dialog-header">\
                        <slot name="header">{{title}}</slot>\
                        <a @click="close">关闭</a>\
                    </div>\
                    <div class="dialog-container">\
                        <slot></slot>\
                    </div>\
                </div>\
            </div>\
        </transition>\
    ',
    props: { context: Object, visible: Boolean, title: String },
    methods: {
        close: function () {
            this.$emit("update:visible", false);
        }
    }
});

