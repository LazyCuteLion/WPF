///<reference path="common.js" />

class SocketBase {
    constructor(url) {
        if (url != undefined)
            this.url = url;
        this.eventMap = new Map();
    }
    baseUrl = "ws://127.0.0.1:9966/";
    /**
     * 初始化连接
     * @param {function({s:WebSocket})} fn 回调 
     */
    init(fn) {
        if (this.socket && this.socket.readyState == WebSocket.CONNECTING) {
            if (typeof fn == "function") {
                const ws = this.socket;
                ws.addEventListener("open", function () {
                    fn(ws);
                });
            }
        }
        else if (this.socket && this.socket.readyState == WebSocket.OPEN) {
            if (typeof fn == "function")
                fn(this.socket);
        }
        else {
            let ws = new WebSocket(this.baseUrl + this.url);
            const base = this;
            base.socket = ws;
            ws.onopen = function () {
                console.log("init:", this.url);
            }
            if (typeof fn == "function") {
                ws.addEventListener("open", function () {
                    fn(ws);
                });
            }
            ws.onmessage = function (e) {
                try {
                    const result = JSON.parse(e.data);
                    if (result.event == "message" && !convert.isNull(result.data))
                        result.data = convert.fromBase64String(result.data);
                    base.onmessage(result);
                }
                catch (error) {
                    console.log(error, e);
                }
            }
            ws.onclose = function () {
                base.socket = undefined;
                base.dispatchEvent("close");
            }
            ws.onerror = function (e) {
                base.socket = undefined;
                base.dispatchEvent("error");
                //console.log(e);
            }
        }
    }
    /**
     * @param {{ip?:string,port:number,data:string,delay?:number,event:"message"|"open"|"close"|"exists"}} packet 
     */
    sendPacket(packet) {
        if (packet == undefined)
            return;
        this.init((socket) => {
            socket.send(JSON.stringify(packet));
            console.log(this.url + " send:", packet);
            console.logTime();
        });
    }
    /**
     * @param {string} data 要发送字符串（将以base64编码,以0x开头将被识别为16进制字符串）
     * @param {string} ip 
     * @param {number} port 0<port<65536
     * @param {number} delay 延时(毫秒,60000以内)[可选]
     */
    send(data, ip, port, delay) {
        if (convert.isNull(data) || !convert.inRange(port, 1, 65535))
            return;
        let packet = {
            port: port,
            data: convert.toBase64String(data),
            event: "message"
        };
        if (!convert.isNull(ip)) {
            packet.ip = ip;
        }
        if (convert.inRange(delay, 100, 60000)) {
            packet.delay = delay;
        }
        this.init((socket) => {
            socket.send(JSON.stringify(packet));
            packet.data = data;
            console.log(this.url + " send:", packet);
            console.logTime();
        });
    }
    /**
     *  监听本地端口或串口
     * @param {number} port 49152~65535
     */
    open(port) {
        if (convert.inRange(port, 1, 65535))
            this.sendPacket({ port: port, event: "open" });
    }
    /**
     * 关闭监听端口
     * @param {number} port 
     */
    close(port) {
        if (convert.inRange(port, 1, 65535))
            this.sendPacket({ port: port, event: "close" });
    }
    /**
     * 是否存在主机或串口或已建立的udp|tcp连接
     * @param {string} ip 
     * @param {number} port 串口或端口[可选]
     */
    exists(ip, port) {
        let packet = { event: "exists" };
        if (!convert.isNull(ip)) {
            packet.ip = ip;
        }
        if (convert.inRange(port, 1, 65535)) {
            packet.port = port;
        }
        if (packet.ip || packet.port)
            this.sendPacket(packet);
    }
    /**
     * 接收websocket消息（没有必要请勿重写该方法）
     * @param {{ip?:string,port:number,data:string,event:"message"|"open"|"close"|"exists"|"error"}} e
     */
    onmessage(e) {
        console.log(this.url + " received:", e);
        console.logTime();
        this.dispatchEvent(e.event, e);
        /**
            switch (e.event) {
                case "message":
                    //base64数据
                    break;
                case "open":
                    //打开串口|udp端口|tcp端口
                    break;
                case "close":
                    //关闭串口|udp端口|tcp端口
                    break;
                case "exists":
                    //是否存在ip或串口
                    break;
                case "error":
                    //发生错误
                    break;
            }
        */
    }
    /**
     * @param {"message"|"open"|"close"|"exists"|"error"} event
     * @param {function({ip:string,port:number,data})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            const key = this.url + "-" + event;
            if (this.eventMap.has(key)) {
                this.eventMap.set(key, this.eventMap.get(key).concat([handler]));
            }
            else {
                this.eventMap.set(key, [handler]);
            }
        }
    }
    /**
     * @param {string} event 
     * @param {object} e 
     */
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            const key = this.url + "-" + event;
            if (this.eventMap.has(key)) {
                const handlers = this.eventMap.get(key);
                for (var i = 0; i < handlers.length; i++) {
                    var fn = handlers[i];
                    if (fn(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
}

class UdpClient extends SocketBase {
    constructor() {
        super("udp");
    }
    /**
     * 广播
     * @param {string} data 
     * @param {number} port 
     * @param {number} delay  延时[可选]
     */
    broadcast(data, port, delay) {
        this.send(data, "255.255.255.255", port, delay);
    }
    /**
     * 唤醒主机
     * @param {string} mac 网卡地址 
     * @param {number} delay 延时[可选]
     */
    wakeonlan(mac, delay) {
        if (!convert.isNull(mac)) {
            let data = "0xFFFFFFFFFFFF";
            mac = mac.replace(/-/g, "").replace(/:/g, "");
            for (let i = 0; i < 16; i++) {
                data += mac;
            }
            this.broadcast(data, 9, delay);
        }
    }
}

class TcpClient extends SocketBase {
    constructor() {
        super("tcp");
    }
    /**
     * 打开本地端口或连接远程主机
     * @param {number} port 端口
     * @param {string} ip 远程主机ip[可选]
     */
    open(port, ip) {
        if (!convert.inRange(port, 1, 65535))
            return;
        let packet = { port: port, event: "open" };
        if (!convert.isNull(ip)) {
            packet.ip = ip;
        }
        this.sendPacket(packet);
    }
    /**
     * 关闭本地端口或断开远程主机
     * @param {number} port 端口
     * @param {string} ip 远程主机[可选]
     */
    close(port, ip) {
        if (!convert.inRange(port, 1, 65535))
            return;
        let packet = { port: port, event: "close" };
        if (!convert.isNull(ip)) {
            packet.ip = ip;
        }
        this.sendPacket(packet);
    }
}

class SerialPort extends SocketBase {
    constructor() {
        super("com");
    }
    /**
     * @param {number} port 串口号
     * @param {number} baudRate [可选] 波特率[9600] 常用 9600|19200|38400|115200 
     * @param {number} parity [可选] 奇偶校验[0] None[0]|Odd[1]|Even[2]|Mark[3]|Space[4]
     * @param {number} dataBits [可选] 数据位[8] 5|6|7|8
     * @param {number} stopBits [可选] 停止位[1] None[0]|One[1]|Two[2]|OnePointFive[3]
     */
    open(port, baudRate, parity, dataBits, stopBits) {
        if (port == undefined || typeof port != "number")
            return;
        let packet = { port: port, event: "open" };
        let data = {
            baudRate: baudRate,
            parity: parity,
            dataBits: dataBits,
            stopBits: stopBits
        };
        if (typeof baudRate == "string") {
            switch (baudRate) {
                case "Odd": data.baudRate = 1; break;
                case "Even": data.baudRate = 2; break;
                case "Mark": data.baudRate = 3; break;
                case "Space": data.baudRate = 4; break;
                default: data.baudRate = 0; break;
            }
        }
        else if (baudRate == null) {
            data.baudRate = 0;
        }

        packet.data = JSON.stringify(data);
        this.sendPacket(packet);
    }
    /**
     * @param {string} data 要发送字符串（将以base64编码，16进制字符串以[0x]开头）
     * @param {number} port 
     * @param {number} delay 延时(毫秒)[可选]
     */
    send(data, port, delay) {
        super.send(data, null, port, delay);
    }
    /**
     * 是否存在串口（不确定是否打开）
     * @param {number} port 
     */
    exists(port) {
        super.exists(null, port);
    }
}

const sockets = {
    udp: new UdpClient(),
    tcp: new TcpClient(),
    com: new SerialPort()
}
