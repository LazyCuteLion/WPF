///<reference path="common.js" />
///<reference path="socket.js" />


class ComputerManager {
    constructor() {
        this.eventMap = new Map();
        const base = this;
        sockets.udp.init();
        sockets.udp.addEventListener("message", function (e) {
            if (convert.isNull(e.ip) || convert.isNull(e.data))
                return;
            if (e.data.startsWith("volume=")) {
                try {
                    const volume = parseInt(e.data.substring(7));
                    const param = { ip: e.ip, port: e.port, data: volume };
                    base.dispatchEvent("volume", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("position=")) {
                try {
                    const position = parseInt(e.data.substring(9));
                    const param = { ip: e.ip, port: e.port, data: position };
                    base.dispatchEvent("position", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("duration=")) {
                try {
                    const duration = parseInt(e.data.substring(9));
                    const param = { ip: e.ip, port: e.port, data: duration };
                    base.dispatchEvent("duration", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("videos=")) {
                try {
                    const videos = JSON.parse(e.data.substring(7));
                    const param = { ip: e.ip, port: e.port, data: videos };
                    base.dispatchEvent("videos", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
        });
        sockets.udp.addEventListener("exists", function (e) {
            if (!convert.isNull(e.ip) && e.port == undefined) {
                base.dispatchEvent("state", { ip: e.ip, port: e.port, data: e.data });
                return true;
            }
        });
    }
    /**
     * @param {"state"|"volume"|"position"|"duration"|"videos"} event 
     * @param {function({ip:string,port:number,data:boolean|number|string[]})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    on(d, delay) {
        if (convert.isNull(d.mac))
            return;
        sockets.udp.wakeonlan(d.mac, delay);
        d.state = null;
    }
    off(d, delay) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.send("shutdown", d.ip, d.port, delay);
        d.state = null;
    }
    restart(d) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.send("restart", d.ip, d.port);
        d.state = null;
    }
    refresh(d) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.exists(d.ip);
        d.state = null;
    }
    setVolume(d) {
        sockets.udp.send("volume=" + d.volume, d.ip, d.port);
    }
    getVolume(d) {
        sockets.udp.send("volume", d.ip, d.port);
    }
    play(d) {
        sockets.udp.send("play", d.ip, 1899);
    }
    pause(d) {
        sockets.udp.send("pause", d.ip, 1899);
    }
    stop(d) {
        sockets.udp.send("stop", d.ip, 1899);
    }
    setPosition(d) {
        sockets.udp.send("position=" + d.position, d.ip, 1899);
    }
    getPosition(d) {
        sockets.udp.send("duration", d.ip, 1899);
        sockets.udp.send("position", d.ip, 1899, 200);
    }
    getVideos(d) {
        sockets.udp.send("videos", d.ip, 1899);
    }
}

class JYBoardManager {
    constructor() {
        this.eventMap = new Map();
        const base = this;
        sockets.udp.init();
        //sockets.com.init();
        function processData(e) {
            let handle = false;
            //if (app.jyboards.some(f => f.port == e.port && f.ip == e.ip)) {
            if (!convert.isNull(e.data)) {
                const result = base.convert(e.data);
                if (result != undefined) {
                    if (convert.inRange(result.board, 1, 254)) {
                        if (convert.isNull(result.data)) {
                            //需要查询状态
                            const cmd = base.refreshCmd(result.board);
                            if (convert.isNull(e.ip)) {
                                sockets.com.send(cmd, e.port, 100);
                            }
                            else {
                                sockets.udp.send(cmd, e.ip, e.port, 100);
                            }
                        }
                        else {
                            if (!convert.isNull(e.ip))
                                result.ip = e.ip;
                            result.port = e.port;
                            base.dispatchEvent("state", result);
                        }
                    }
                    handle = true;
                }
            }
            //}
            return handle;
        }
        sockets.udp.addEventListener("message", processData);
        //sockets.com.addEventListener("message", processData);
    }
    /**
     * state:开关状态
     * @param {"state"} event
     * @param {function({ip?:string,port:number,board:number,no?:number,data:boolean[]})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    /**
     * 分析聚英继电器返回值
     * @param {string} data 
     * @returns {{board:number,no?:number,data:boolean[]}} 
     */
    convert(data) {
        const hex = convert.toBytes(data);
        if ((hex[0] > 0 && hex[0] < 255)) {
            //crc校验
            if (CRC16.check(hex)) {
                let result = { board: hex[0], data: [] };
                //Modbus协议 功能码
                switch (hex[1]) {
                    case 0x01:
                        for (let i = 0; i < hex[2]; i++) {
                            //聚英的继电器最多32路(4x8) hex[2]<=4
                            const s = hex[3 + i].toString(2).padStart(8, "0");
                            console.log("jyboard state:" + s);
                            //从右往左，高位在左低位在右
                            for (let n = 7; n >= 0; n--) {
                                result.data.push(s[n] == "1");
                            }
                        }
                        break;
                    case 0x05:
                        result.no = hex[3] + 1;
                        result.data.push(hex[4] == 0xFF);
                        break;
                    case 0x10:
                    case 0x0F:
                        //返回值不包含线圈状态，需要主动查询
                        break;
                    default:
                        //不支持的功能
                        result.board = -1;
                        break;
                }
                return result;
            }
        }
    }
    send(cmd, port, ip, delay) {
        if (convert.isNull(ip)) {
            sockets.com.send(cmd, port, delay);
        }
        else {
            sockets.udp.send(cmd, ip, port, delay);
        }
    }
    on(d, delay) {
        const cmd = this.onCmd(d.board, d.no);
        this.send(cmd, d.port, d.ip, delay);
    }
    off(d, delay) {
        const cmd = this.offCmd(d.board, d.no);
        this.send(cmd, d.port, d.ip, delay);
    }
    refresh(d) {
        const cmd = this.refreshCmd(d.board);
        this.send(cmd, d.port, d.ip);
    }
    /**
     * 获取闭合指令
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} no 开关号（1~32）为空则取全部[8路]开关，-1|-2|-4|-8|-16|-32 则表示开关数量
     */
    onCmd(board = 254, no = -8) {
        let cmd = [board];
        if (no == undefined || no < 0) {
            cmd.push(0x0F);
            //起始地址
            cmd.push(0x00);
            cmd.push(0x00);
            //数量
            cmd.push(0x00);
            cmd.push(no * -1);
            //指令字节
            if (no >= -8) {
                cmd.push(0x01);
                cmd.push(0xFF);
            }
            else if (no >= -16) {
                cmd.push(0x02);
                cmd.push(0xFF);
                cmd.push(0xFF);
            }
            else if (no >= -32) {
                cmd.push(0x04);
                cmd.push(0xFF);
                cmd.push(0xFF);
                cmd.push(0xFF);
                cmd.push(0xFF);
            }
        }
        else if (no >= 1 && no <= 32) {
            cmd.push(0x05);
            //地址
            cmd.push(0x00);
            cmd.push(no - 1);
            //指令
            cmd.push(0xFF);
            cmd.push(0x00);
        }
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
    /**
     * 获取断开指令
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} no 开关号（1~32）为空则取全部[8路]开关，-1|-2|-4|-8|-16|-32 则表示开关数量
     */
    offCmd(board = 254, no = -8) {
        let cmd = [board];
        if (no == undefined || no < 0) {
            cmd.push(0x0F);
            //起始地址
            cmd.push(0x00);
            cmd.push(0x00);
            //数量
            cmd.push(0x00);
            cmd.push(no * -1);
            //指令字节
            if (no >= -8) {
                cmd.push(0x01);
                cmd.push(0x00);
            }
            else if (no >= -16) {
                cmd.push(0x02);
                cmd.push(0x00);
                cmd.push(0x00);
            }
            else if (no >= -32) {
                cmd.push(0x04);
                cmd.push(0x00);
                cmd.push(0x00);
                cmd.push(0x00);
                cmd.push(0x00);
            }
        }
        else if (no >= 1 && no <= 32) {
            cmd.push(0x05);
            //地址
            cmd.push(0x00);
            cmd.push(no - 1);
            //指令
            cmd.push(0x00);
            cmd.push(0x00);
        }
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
    /**
     * 获取查询指令(全部开关)
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} count 继电器数量（默认8个）
     */
    refreshCmd(board = 254, count = 8) {
        let cmd = [board, 0x01, 0x00, 0x00, 0x00, count];
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
}

class PJLinkManager {
    constructor(pwd) {
        if (pwd != undefined)
            this.pwd = pwd;
        else
            this.pwd = "panasonic";
        this.eventMap = new Map();
        this.cacheMap = new Map();
        const base = this;
        sockets.tcp.init();
        sockets.tcp.addEventListener("open", function (e) {
            //投影机在建立连接时，在2s内返回[PJLINK 0|1]
            setTimeout(function (ip, port) {
                base.send(ip, port);
            }, 2000, e.ip, e.port);
        });
        sockets.tcp.addEventListener("message", function (e) {
            //建立连接时，投影机在2s内返回 [PJLINK 0|1] 是否需要验证
            const key = e.ip + ":" + e.port;
            if (e.data.startsWith("PJLINK")) {
                if (e.data[7] == "1" || e.data[7] == "0") {
                    let token = "";
                    if (e.data[7] == "1") {
                        //计算token 
                        const rd = e.data.substring(9, 17) + base.pwd;
                        token = convert.toMD5String(rd);
                    }
                    if (base.cacheMap.has(key)) {
                        base.cacheMap.get(key).token = token;
                        base.send(e.ip, e.port);
                    }
                    else {
                        base.cacheMap.set(key, { token: token });
                    }
                }
                else if (e.data.indexOf("ERRA") > 0) {
                    //验证码错误，断开连接
                    sockets.tcp.close(e.port, e.ip);
                }

                return true;
            }
            else if (e.data.startsWith("%1POWR=")) {
                //状态
                if (e.data[7] == "0") {
                    base.dispatchEvent("state", { ip: e.ip, port: e.port, data: false });
                }
                else if (e.data[7] == "1") {
                    base.dispatchEvent("state", { ip: e.ip, port: e.port, data: true });
                }
                else {
                    //稍后查询
                    if (base.cacheMap.has(key)) {
                        const cache = base.cacheMap.get(key);
                        //判断是否需要查询状态
                        if (cache.needRefresh) {
                            sockets.tcp.send(cache.token + "%1POWR ?\r", e.ip, e.port, 10000);//投影机开机一般需要10s
                            delete cache.needRefresh;
                        }
                    }
                }
                return true;
            }
        });
        function clear(e) {
            if (e) {
                const key = e.ip + ":" + e.port;
                if (base.cacheMap.has(key)) {
                    base.cacheMap.delete(key);
                }
            }
            else {
                base.cacheMap.clear();
            }
        }
        sockets.tcp.addEventListener("close", clear);
        sockets.tcp.addEventListener("error", clear);

    }
    /**
     * state:开关状态
     * @param {string} event state
     * @param {function({ip:string,port:number,data:boolean})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    /**
     * @param {"state"} event 
     * @param {{ip:string,port:number,data:boolean}} e 
     */
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    send(ip, port) {
        const key = ip + ":" + port;
        if (this.cacheMap.has(key)) {
            const cache = this.cacheMap.get(key);
            if (!convert.isNull(cache.cmd)) {
                if (cache.token == undefined)
                    cache.token = "";
                sockets.tcp.send(cache.token + cache.cmd, ip, port, cache.delay);
                //清除指令
                delete cache.cmd;
                delete cache.delay;
            }
        }
    }
    invoke(d, cmd, delay) {
        const key = d.ip + ":" + d.port;
        if (delay >= 30000)//pjlink 保持连接30s
            delay = 29800;

        const cache = this.cacheMap.has(key) ? this.cacheMap.get(key) : { cmd: cmd, delay: delay };
        if (cmd == "%1POWR 1\r" || cmd == "%1POWR 0\r") {
            //需要刷新状态
            cache.needRefresh = true;
            //d.state = null;
        }
        //没有缓存
        if (!this.cacheMap.has(key)) {
            this.cacheMap.set(key, cache);
            //建立tcp连接
            sockets.tcp.open(d.port, d.ip);
            //1.tcp不存在，建立连接，返回open，返回PJLINK
            //2.tcp连接已存在，返回open
        }
        else {
            if (!convert.isNull(cache.cmd)) {
                console.log("存在缓存的pjlink指令！");
                return;
            }
            if (cache.token != undefined) {
                sockets.tcp.send(cache.token + cmd, d.ip, d.port, delay);
            }
        }
    }
    on(d, delay) {
        this.invoke(d, "%1POWR 1\r", delay);
    }
    off(d, delay) {
        this.invoke(d, "%1POWR 0\r", delay);
    }
    refresh(d) {
        this.invoke(d, "%1POWR ?\r");
        sockets.tcp.exists(d.ip);
    }
}

const managers = {
    computer: new ComputerManager(),
    pjlink: new PJLinkManager(),
    jyboard: new JYBoardManager()
};