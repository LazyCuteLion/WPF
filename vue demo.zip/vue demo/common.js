
String.prototype.padLeft = function (length, char) {
    if (this.length >= length)
        return this;
    return new Array(length - this.length + 1).join(char) + this;
}
String.prototype.padRight = function (length, char) {
    if (this.length >= length)
        return this;
    return this + new Array(length - this.length + 1).join(char);
}
Array.prototype.distinct = function (key) {
    let result = [];
    let find = {};
    for (let i = 0; i < this.length; i++) {
        const item = this[i];
        if (key) {
            const v = item[key];
            if (result.indexOf(v) < 0) {
                result.push(v);
            }
        } else {
            if (!find[item]) {
                result.push(item);
                find[item] = 1;
            }
        }
    }
    return result;
}
Number.prototype.toTimeSpan = function () {
    if (this == 0)
        return "00:00:00";
    let ms = this;
    let h = parseInt(ms / 1000 / 60 / 60);
    ms -= h * 1000 * 60 * 60;//减去小时
    let m = parseInt(ms / 1000 / 60);
    ms -= m * 1000 * 60;//减去分钟
    let s = parseInt(ms / 1000);
    return h.toString().padLeft(2, "0")
        + ":"
        + m.toString().padLeft(2, "0")
        + ":"
        + s.toString().padLeft(2, "0");
}
console.logTime = function () {
    const dt = new Date();
    console.log(dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds() + "." + dt.getMilliseconds());
    console.log();
}

const convert = {
    /**
     * 16进制字符串转换为二进制数组
     * @param {string} str 16进制字符串 
     */
    fromHexString(str) {
        if (str.startsWith("0x"))
            str = str.substr(2);
        let data = [];
        for (let i = 0; i < str.length; i += 2) {
            const n = parseInt(str.substr(i, 2), 16);
            data.push(n);
        }
        return data;
    },
    /**
     * 以base64解码
     * @param {string} str base64字符串
     */
    fromBase64String(str) {
        let result = window.atob(str);
        // try {
        //     result = UTF8.decode(result);
        // } catch (e) { }
        return result;
    },
    /**
     * 以base64编码
     * @param {string|[]} s 
     */
    toBase64String(s) {
        let code = s;
        if (typeof s == "string") {
            if (s.startsWith("0x")) {
                code = convert.fromHexString(s);
            }
            //是否包含中文
            else if (/.*[\u4e00-\u9fa5]+.*$/.test(s)) {
                code = UTF8.encode(s);
            }
        }
        return window.btoa(code);
    },
    /**
     * 转换为二进制数组
     * @param {string} str 
     */
    toBytes(str) {
        if (str.startsWith("0x"))
            return convert.fromHexString(str);
        let data = [];
        for (var i = 0; i < str.length; i++) {
            data.push(str.charCodeAt(i));
        }
        return data;
    },
    /**
     * 二进制数组转换为字符串
     * @param {Array} bytes 
     */
    toString(bytes) {
        let str = "";
        for (let i = 0; i < bytes.length; i++) {
            str += String.fromCharCode(bytes[i]);
        }
        return str;
    },
    /**
     * 转换为16进制字符串
     * @param {*} bytes 二进制数组或字符串
     */
    toHexString(bytes) {
        let str = "0x";
        const isArray = Array.isArray(bytes);
        for (let i = 0; i < bytes.length; i++) {
            if (isArray)
                str += bytes[i].toString(16).toUpperCase().padLeft(2, "0");
            else
                str += bytes.charCodeAt(i).toString(16).toUpperCase().padLeft(2, "0");
        }
        return str;
    },
    isNull(s) {
        return s == undefined || s == null || s === "" || s.length < 1;
    },
    /**
     * @param {number} s 
     * @param {number} min 
     * @param {number} max 
     */
    inRange(s, min, max) {
        if (s == undefined || typeof s != "number")
            return false;
        return s >= min && s <= max;
    }
}

const UTF8 = {
    encode: function (s) {
        let code = encodeURIComponent(s);
        const bytes = [];
        for (let i = 0; i < code.length; i++) {
            const c = code.charAt(i);
            if (c === "%") {
                const hex = code.charAt(i + 1) + code.charAt(i + 2);
                bytes.push(parseInt(hex, 16));
                i += 2;
            }
            else {
                bytes.push(c.charCodeAt(0));
            }
        }
        return bytes;
    },
    decode: function (s) {
        const type = Array.isArray(s) ? "array" : typeof s;
        let code = "";
        for (let i = 0; i < s.length; i++) {
            switch (type) {
                case "string": code += "%" + s.charCodeAt(i).toString(16); break;
                case "array": code += "%" + s[i].toString(16); break;
            }
        }
        return decodeURIComponent(code);
    }
}

const CRC16 = {
    crcHi: [
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
        0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
        0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
        0x00, 0xC1, 0x81, 0x40
    ],
    crcLo: [
        0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03,
        0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7,
        0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C,
        0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E,
        0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
        0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9,
        0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE,
        0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC,
        0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17,
        0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
        0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30,
        0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32,
        0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35,
        0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D,
        0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
        0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,
        0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B,
        0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF,
        0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24,
        0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
        0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21,
        0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1,
        0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6,
        0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4,
        0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
        0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB,
        0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8,
        0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA,
        0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD,
        0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
        0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2,
        0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0,
        0x50, 0x90, 0x91, 0x51, 0x93, 0x53,
        0x52, 0x92, 0x96, 0x56, 0x57, 0x97,
        0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
        0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E,
        0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59,
        0x58, 0x98, 0x88, 0x48, 0x49, 0x89,
        0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E,
        0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
        0x44, 0x84, 0x85, 0x45, 0x87, 0x47,
        0x46, 0x86, 0x82, 0x42, 0x43, 0x83,
        0x41, 0x81, 0x80, 0x40
    ],
    calculate: function (hex) {
        let data = hex;
        if (typeof hex == "string") {
            data = convert.toBytes(hex);
        }
        if (!Array.isArray(data) || data.length < 1)
            return;
        let high = 0xFF;
        let low = 0xFF;
        let index = 0;
        for (let i = 0; i < data.length; i++) {
            index = (low ^ data[i]) & 0xFF;
            low = high ^ this.crcHi[index];
            high = this.crcLo[index];
        }
        //低位在前，高位在后
        return [low, high];
    },
    check: function (hex) {
        let temp = typeof hex == "string" ? convert.toBytes(hex) : hex;
        if (!Array.isArray(temp))
            return false;
        const crc = this.calculate(temp.slice(0, temp.length - 2));
        const r = (crc[0] == temp[temp.length - 2] && crc[1] == temp[temp.length - 1]);
        if (!r)
            console.log("%c CRC校验失败 " + (Array.isArray(hex) ? hex.toHexString() : hex) + " crc:" + crc.toHexString(), "color:red;");
        return r;
    }
}

String.prototype.fromHexString = function () {
    return convert.fromHexString(this);
}
String.prototype.fromBase64String = function () {
    return convert.fromBase64String(this);
}
String.prototype.toBase64String = function () {
    return convert.toBase64String(this);
}
String.prototype.toBytes = function () {
    return convert.toBytes(this);
}
String.prototype.toHexString = function () {
    return convert.toHexString(this);
}

Array.prototype.toBase64String = function () {
    return convert.toBase64String(this);
}
Array.prototype.toString = function () {
    return convert.toString(this);
}
Array.prototype.toHexString = function () {
    return convert.toHexString(this);
}

