///<reference path="socket.js" />
///<reference path="common.js" />

Vue.component("meida-player", {
    props: ["context", "manager"],
    template: `
        <div :data-host='context.host.join()'>
            <template v-if="hasVideo">
                <div class="btn-default" @click="manager.play(context)">
                    播放
                </div>
                <div class="btn-default" @click="manager.pause(context)">
                    暂停
                </div>
                <div class="btn-default" @click="manager.stop(context)">
                    停止
                </div>
                <div>
                    音量
                    <input type="range" v-model.number="context.volume" @change="manager.setVolume(context)">
                    <span>
                        {{context.volume}}
                    </span>
                </div>
                <br>
                <div>
                    <span>
                        {{position_ts}}
                    </span>
                    <input type="range" v-model.number="context.position" :max="context.duration" 
                        style="width:600px;"
                        @change="manager.setPosition(context)"
                        @mousedown="stopProgress">
                    <span>
                        {{duration_ts}}
                    </span>
                </div>
            </template>
            <template v-else>
                 <div>
                    音量
                    <input type="range" v-model.number="context.volume" @change="setVolume">
                    <span>
                        {{context.volume}}
                    </span>
                </div>
            </template>
        </div>
        `,
    computed: {
        hasVideo: function () {
            return this.context.videos != undefined && Array.isArray(this.context.videos);
        },
        position_ts: function () {
            if (this.context.position != undefined)
                return this.context.position.toTimeSpan();
        },
        duration_ts: function () {
            if (this.context.duration != undefined)
                return this.context.duration.toTimeSpan();
        }
    },
    methods: {
        stopProgress() {
            if (this.context.progress != undefined && this.context.progress > 0) {
                clearInterval(this.context.progress);
                this.context.progress = -1;
            }
        }
    }
});

Vue.component("my-dialog", {
    template: '\
        <transition name="fade">\
            <div v-show="visible" class="dialog">\
                <div>\
                    <div class="dialog-header">\
                        <slot name="header">{{title}}</slot>\
                        <a @click="close">关闭</a>\
                    </div>\
                    <div class="dialog-container">\
                        <slot></slot>\
                    </div>\
                </div>\
            </div>\
        </transition>\
    ',
    props: { context: Object, visible: Boolean, title: String },
    methods: {
        close: function () {
            this.$emit("update:visible", false);
        }
    }
});

//页面第一次加载不会响应[visibilitychange]（因为以下代码在页面加载后才运行）
window.addEventListener("visibilitychange", function () {
    console.log("page:", document.visibilityState);
    if (document.visibilityState == "hidden") {
        //清除进度条的动画
        //if (app.openDialog) {
        app.selection.mediaPlayers.forEach(f => {
            if (f.progress != undefined && f.progress > 0) {
                clearInterval(f.progress);
                f.progress = -1;
            }
        });
        //}
    }
    else if (document.visibilityState == "visible") {
        if (app.openDialog) {
            app.selection.mediaPlayers.forEach(f => {
                //managers.computer.getVideos(f);
                managers.computer.getPosition(f);
            });
        }
    }
});


const app = new Vue({
    el: "#main",
    data: {
        selectedText: "",
        openDialog: false,
        menus: [],
        mediaPlayers: [],//内容控制 目前主要是视频播放
        computers: [],
        projectors: [],
        jyboards: [],
        powerTimingDevices: []
    },
    created() {
        //获取数据
        // axios.get("data.json").then(function (res) {
        //     app.menus = res.data;
        // });

        //菜单
        this.menus = [{
            name: "",//菜单名称 [key]
            x: 0,//按钮坐标x
            y: 0//按钮坐标y
        }];

        //播放器主机
        this.mediaPlayers = [
            {
                template: "media-player",//播放器模板
                menu: "",//所属菜单
                host: ["192.168.0.3:1699", "192.168.0.2:1699"],//多台主机同步
                volume: 0,//音量
                videos: [],//视频列表
                position: 0,//播放进度
                duration: 66000//视频时长
            },
            {
                template: "media-player",//播放器模板
                menu: "",//所属菜单
                host: ["127.0.0.1:1699"],
                volume: 0,//音量
                videos: [],//视频列表
                position: 0,//播放进度
                duration: 66000//视频时长
            }
        ];

        //电脑主机(全部)
        this.computers = [{
            template: "computer",//主机模板
            menu: "",//所属菜单
            name: "", //名称
            ip: "127.0.0.1",//ip地址
            port: 1699,//端口 
            mac: "00-00-00-00-00-01",//网卡地址
            state: false,//电源状态
            online: false,//通信状态 可选
        }];

        //投影机(全部)
        this.projectors = [{
            template: "pjlink",//投影机模板 pjlink协议
            menu: "",
            name: "",
            ip: "",
            port: 4352,
            state: false,
            online: false,
        }];

        //聚英继电器(全部)
        this.jyboards = [
            {
                template: "jyboard",
                ip: "127.0.0.1",//网络控制
                port: 10000,
                items: [{
                    template: "light|electrical|sanboard",//照明灯光、电器、沙盘灯光
                    name: "",
                    board: 1,//板卡地址（拨码）
                    no: 1,//开关号 
                    state: false,
                    menu: ""//所属菜单
                }]
            },
            {
                template: "jyboard",//聚英继电器
                port: 5,//串口控制
                items: [{
                    template: "light|electrical",//灯光或电器
                    name: "",
                    board: 1,//板卡地址（拨码）
                    no: 1,//开关号 
                    state: false,
                }]
            }
        ]

        //电源时序器
        this.powerTimingDevices = [
            {
                template: "power-timing-device",
                name: "",
                ip: "",
                port: ""
            }
        ]
    },
    mounted() {
        //初始化websocket

        function stateChanged(e) {
            const find = app.computers.find(f => f.ip == e.ip);
            if (find != undefined) {
                find.state = e.data;
                return true;
            }
        }
        //主机状态
        managers.computer.addEventListener("state", stateChanged);
        //投影机状态
        managers.pjlink.addEventListener("state", stateChanged);

        //音量
        managers.computer.addEventListener("volume", function (e) {
            const find = app.mediaPlayers.find(f => f.host.some(t => t.startsWith(e.ip)));
            if (find != undefined) {
                app.$set(find, "volume", e.data);
                return true;
            }
        });
        //视频列表
        managers.computer.addEventListener("videos", function (e) {
            const find = app.mediaPlayers.find(f => f.host.some(t => t.startsWith(e.ip)));
            if (find != undefined) {
                app.$set(find, "videos", e.data);
                return true;
            }
        });
        //视频当前进度
        managers.computer.addEventListener("position", function (e) {
            const find = app.mediaPlayers.find(f => f.host.some(t => t.startsWith(e.ip)));
            if (find != undefined && find.position != undefined) {
                //先停止当前进度条
                if (find.progress != undefined && find.progress > 0) {
                    clearInterval(find.progress);
                    find.progress = -1;
                }
                if (find.duration > e.data) {
                    if (e.data >= 0) {
                        find.position = e.data;
                        find.progress = setInterval(function () {
                            find.position += 100;
                            if (find.position >= find.duration) {
                                clearInterval(find.progress);
                                find.progress = -1;
                                find.position = find.duration;
                            }
                        }, 100);
                    }
                }
                return true;
            }
        });
        //视频时长
        managers.computer.addEventListener("duration", function (e) {
            const find = app.mediaPlayers.find(f => f.host.some(t => t.startsWith(e.ip)));
            if (find != undefined && find.duration != undefined) {
                //时长<=0,则表示停止
                if (e.data <= 0) {
                    if (find.progress != undefined && find.progress > 0) {
                        clearInterval(find.progress);
                        find.progress = -1;
                    }
                    find.position = 0;
                }
                else {
                    find.duration = e.data;
                }
                return true;
            }
        });

        //聚英继电器状态
        managers.jyboard.addEventListener("state", function (e) {
            const find = app.jyboards.find(f => f.port == e.port && (f.ip == e.ip || e.ip == undefined));
            if (find != undefined) {
                if (e.no == undefined && e.data.length > 1) {
                    const items = find.items.filter(t => t.board == e.board);
                    if (!convert.isNull(items)) {
                        items.forEach(item => {
                            if (item.no <= e.data.length) {
                                item.state = e.data[item.no - 1];
                            }
                        });
                    }
                }
                else {
                    const item = find.items.find(t => t.board == e.board && t.no == e.no);
                    if (item != undefined) {
                        item.state = e.data[0];
                    }
                }
                return true;
            }
        });
    },
    computed: {
        selection() {
            const menu = this.selectedText;

            let result = {
                mediaPlayers: app.mediaPlayers.filter(f => f.menu == menu),
                computers: app.computers.filter(f => f.menu == menu),
                projectors: app.projectors.filter(f => f.menu == menu)
            };

            for (let i = 0; i < app.jyboards.length; i++) {
                const jyboard = app.jyboards[i];
                for (let j = 0; j < jyboard.items.length; j++) {
                    const item = jyboard.items[j];
                    if (item.menu == menu) {
                        switch (item.template) {
                            case "light":
                                if (!result.lights || !Array.isArray(result.lights))
                                    result.lights = [];
                                result.lights.push(item);
                                break;
                            case "electrical":
                                if (!result.electricals || !Array.isArray(result.electricals))
                                    result.electricals = [];
                                result.electricals.push(item);
                                break;
                            case "sanboard":
                                if (!result.sanboards || !Array.isArray(result.sanboards))
                                    result.sanboards = [];
                                result.sanboards.push(item);
                                break;
                        }
                    }
                }
            }

            return result;
        },
        managers() {
            return managers;
        }
    },
    watch: {
        openDialog(v) {
            if (v) {
                //弹窗打开时：
                //查询主机状态/投影机状态/聚英继电器状态
                //查询播放器 volume,position,duration,videos
            }
            else {
                //弹窗关闭时：

            }
        },
        selectedText(newValue, oldValue) {
            if (newValue != oldValue) {

            }
        }
    },
    methods: {
        open(menu) {
            if (this.openDialog)
                return;
            this.selectedText = menu;
            this.openDialog = true;
        },
        on(d) {
            managers[d.template].on(d);
        },
        off(d) {
            managers[d.template].off(d);
        },
        refresh(d) {
            managers[d.template].refresh(d);
        },
        restart(d) {
            managers[d.template].restart(d);
        }

    }
});

