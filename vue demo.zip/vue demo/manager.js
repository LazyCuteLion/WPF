///<reference path="common.js" />
///<reference path="socket.js" />

class ComputerManager {
    constructor() {
        this.eventMap = new Map();
        this.syncHost = [];
        const base = this;
        sockets.udp.init();
        sockets.udp.addEventListener("message", function (e) {
            if (convert.isNull(e.ip) || convert.isNull(e.data))
                return;
            if (e.data.startsWith("volume=")) {
                try {
                    const volume = parseInt(e.data.substr(7));
                    const param = { ip: e.ip, port: e.port, data: volume };
                    base.dispatchEvent("volume", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("position=")) {
                try {
                    const position = parseInt(e.data.substr(9));
                    const param = { ip: e.ip, port: e.port, data: position };
                    base.dispatchEvent("position", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("duration=")) {
                try {
                    const duration = parseInt(e.data.substr(9));
                    const param = { ip: e.ip, port: e.port, data: duration };
                    base.dispatchEvent("duration", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data.startsWith("videos=")) {
                try {
                    const videos = JSON.parse(e.data.substr(7));
                    const param = { ip: e.ip, port: e.port, data: videos };
                    base.dispatchEvent("videos", param);
                    return true;
                }
                catch (er) {
                    console.log(er);
                }
            }
            else if (e.data == "video_loaded") {
                if (convert.isNull(base.syncHost))
                    return true;
                const key = e.ip + ":" + e.port;
                let index = -1;
                for (let i = 0; i < base.syncHost.length; i++) {
                    const item = base.syncHost[i];
                    if (item.host.some(f => f == key)) {
                        item.count++;
                        if (item.count == item.host.length) {
                            index = i;
                            base.send(item, "play");
                            console.log("playsync");
                            console.logTime();
                        }
                        break;
                    }
                }
                //清除待同步列表
                if (index >= 0) {
                    base.syncHost.splice(index, 1);
                }
                return true;
            }
        });
        sockets.udp.addEventListener("exists", function (e) {
            if (!convert.isNull(e.ip) && typeof e.data == "boolean") {
                base.dispatchEvent("state", { ip: e.ip, port: e.port, data: e.data });
                return true;
            }
        });
    }
    /**
     * @param {"state"|"volume"|"position"|"duration"|"videos"} event 
     * @param {function({ip:string,port:number,data:boolean|number|string[]})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    on(d, delay) {
        if (convert.isNull(d.mac))
            return;
        sockets.udp.wakeonlan(d.mac, delay);
        d.state = null;
    }
    off(d, delay) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.send("shutdown", d.ip, d.port, delay);
        d.state = null;
    }
    restart(d) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.send("restart", d.ip, d.port);
        d.state = null;
    }
    refresh(d) {
        if (convert.isNull(d.ip))
            return;
        sockets.udp.exists(d.ip);
        d.state = null;
    }
    send(d, cmd) {
        if (convert.isNull(d.host))
            return;
        d.host.forEach(f => {
            let temp = f.split(":");
            let port = 1699;
            try {
                port = parseInt(temp[1]);
            } catch (e) { }
            sockets.udp.send(cmd, temp[0], port);
        });
    }
    play(d) {
        if (convert.isNull(d.host))
            return;
        if (d.host.length == 1) {
            this.send(d, "play");
        }
        else if (d.host.length > 1) {
            this.syncHost.push({ count: 0, host: d.host });
            this.send(d, "playsync");
        }
    }
    pause(d) {
        this.send(d, "pause");
    }
    stop(d) {
        this.send(d, "stop");
    }
    setVolume(d) {
        if (!convert.inRange(d.volume, 0, 100))
            return;
        this.send(d, "volume=" + d.volume);
    }
    getVolume(d) {
        if (convert.isNull(d.host))
            return;
        let temp = d.host[0].split(":");
        let port = 1699;
        try {
            port = parseInt(temp[1]);
        } catch (e) { }
        sockets.udp.send("volume", temp[0], port);
    }
    setPosition(d) {
        if (d.position == undefined)
            return;
        this.send(d, "position=" + d.position);
    }
    getPosition(d) {
        if (convert.isNull(d.host))
            return;
        let temp = d.host[0].split(":");
        let port = 1699;
        try {
            port = parseInt(temp[1]);
        } catch (e) { }
        sockets.udp.send("duration", temp[0], port);
        sockets.udp.send("position", temp[0], port, 1000);
    }
    getVideos(d) {
        if (convert.isNull(d.host))
            return;
        let temp = d.host[0].split(":");
        let port = 1699;
        try {
            port = parseInt(temp[1]);
        } catch (e) { }
        sockets.udp.send("videos", temp[0], port);
    }
}

class JYBoardManager {
    constructor() {
        this.eventMap = new Map();
        const base = this;
        sockets.udp.init();
        sockets.com.init();
        function processData(e) {
            let handle = false;
            if (!convert.isNull(e.data)) {
                const result = base.convert(e.data);
                if (result != undefined) {
                    if (convert.inRange(result.board, 1, 254)) {
                        if (convert.isNull(result.data)) {
                            //需要查询状态
                            const cmd = base.refreshCmd(result.board);
                            if (convert.isNull(e.ip)) {
                                sockets.com.send(cmd, e.port, 100);
                            }
                            else {
                                sockets.udp.send(cmd, e.ip, e.port, 100);
                            }
                        }
                        else {
                            if (!convert.isNull(e.ip))
                                result.ip = e.ip;
                            result.port = e.port;
                            base.dispatchEvent("state", result);
                        }
                    }
                    handle = true;
                }
            }
            return handle;
        }
        sockets.udp.addEventListener("message", processData);
        sockets.com.addEventListener("message", processData);
    }
    /**
     * state:开关状态
     * @param {"state"} event
     * @param {function({ip:string,port:number,board:number,no?:number,data:[]})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    /**
     * 分析聚英继电器返回值
     * @param {string} data 
     * @returns {{board:number,no?:number,data:boolean[]}} 
     */
    convert(data) {
        const hex = data.toBytes();
        if ((hex[0] > 0 && hex[0] < 255)) {
            //crc校验
            if (CRC16.check(hex)) {
                let result = { board: hex[0], data: [] };
                //Modbus协议 功能码
                switch (hex[1]) {
                    case 0x01:
                        for (let i = 0; i < hex[2]; i++) {
                            //聚英的继电器最多32路(4x8) hex[2]<=4
                            const s = hex[3 + i].toString("2").padLeft(8, "0");
                            console.log("state:" + s);
                            //从右往左，高位在左低位在右
                            for (let n = 7; n >= 0; n--) {
                                result.data.push(s[n] == "1");
                            }
                        }
                        break;
                    case 0x05:
                        result.no = hex[3] + 1;
                        result.data.push(hex[4] == 0xFF);
                        break;
                    case 0x10:
                    case 0x0F:
                        //返回值不包含线圈状态，需要主动查询
                        break;
                    default:
                        //不支持的功能
                        result.board = -1;
                        break;
                }
                return result;
            }
        }
    }
    send(cmd, port, ip, delay) {
        if (convert.isNull(ip)) {
            sockets.com.send(cmd, port, delay);
        }
        else {
            sockets.udp.send(cmd, ip, port, delay);
        }
    }
    on(d, delay) {
        const cmd = this.onCmd(d.board, d.no);
        this.send(cmd, d.port, d.ip, delay);
    }
    off(d, delay) {
        const cmd = this.offCmd(d.board, d.no);
        this.send(cmd, d.port, d.ip, delay);
    }
    refresh(d) {
        const cmd = this.refreshCmd(d.board);
        this.send(cmd, d.port, d.ip);
    }
    /**
     * 获取闭合指令
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} no 开关号（1~32）为空则取全部[8路]开关，-8|-16|-32 则表示开关数量
     */
    onCmd(board = 254, no = -8) {
        let cmd = [board];
        if (no == undefined || no < 0) {
            cmd.push(0x0F);
            //起始地址
            cmd.push(0x00);
            cmd.push(0x00);
            //数量
            cmd.push(0x00);
            cmd.push(no * -1);
            //指令字节
            if (no >= -8) {
                cmd.push(0x01);
                cmd.push(0xFF);
            }
            else if (no >= -16) {
                cmd.push(0x02);
                cmd.push(0xFF);
                cmd.push(0xFF);
            }
            else if (no >= -32) {
                cmd.push(0x04);
                cmd.push(0xFF);
                cmd.push(0xFF);
                cmd.push(0xFF);
                cmd.push(0xFF);
            }
        }
        else if (no >= 1 && no <= 32) {
            cmd.push(0x05);
            //地址
            cmd.push(0x00);
            cmd.push(no - 1);
            //指令
            cmd.push(0xFF);
            cmd.push(0x00);
        }
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
    /**
     * 获取断开指令
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} no 开关号（1~32）为空则取全部[8路]开关，-8|-16|-32 则表示开关数量
     */
    offCmd(board = 254, no = -8) {
        let cmd = [board];
        if (no == undefined || no < 0) {
            cmd.push(0x0F);
            //起始地址
            cmd.push(0x00);
            cmd.push(0x00);
            //数量
            cmd.push(0x00);
            cmd.push(no * -1);
            //指令字节
            if (no == -8) {
                cmd.push(0x01);
                cmd.push(0x00);
            }
            else if (no == -16) {
                cmd.push(0x02);
                cmd.push(0x00);
                cmd.push(0x00);
            }
            else if (no == -32) {
                cmd.push(0x04);
                cmd.push(0x00);
                cmd.push(0x00);
                cmd.push(0x00);
                cmd.push(0x00);
            }
        }
        else if (no >= 1 && no <= 32) {
            cmd.push(0x05);
            //地址
            cmd.push(0x00);
            cmd.push(no - 1);
            //指令
            cmd.push(0x00);
            cmd.push(0x00);
        }
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
    /**
     * 获取查询指令(全部开关)
     * @param {number} board 1~253 设备地址=拨码开关地址(0~31)+偏移地址（多个串联时，不使用地址[0]，因为地址[0]只能用广播地址[254]通信，而串联时不建议使用广播地址）
     * @param {number} count 继电器数量（默认8个）
     */
    refreshCmd(board = 254, count = 8) {
        let cmd = [board, 0x01, 0x00, 0x00, 0x00, count];
        const crc = CRC16.calculate(cmd);
        return cmd.concat(crc);
    }
}

class PJLinkManager {
    constructor(pwd) {
        if (pwd != undefined)
            this.pwd = pwd;
        else
            this.pwd = "";
        this.eventMap = new Map();
        this.tokenMap = new Map();
        this.cmdMap = new Map();
        const base = this;
        sockets.tcp.init();
        sockets.tcp.addEventListener("open", function (e) {
            base.send(e.ip, e.port);
        });
        sockets.tcp.addEventListener("message", function (e) {
            //建立连接时，投影机会返回 [PJLINK 0|1] 是否需要验证
            if (e.data.startsWith("PJLINK")) {
                let token = "";
                if (e.data.substr(7, 1) == "1") {
                    //计算token
                }
                base.tokenMap.set(e.ip + ":" + e.port, token);
                base.send(e.ip, e.port);
                return true;
            }
            else {

            }
        });
        function clear(e) {
            const key = e.ip + ":" + e.port;
            if (base.tokenMap.has(key)) {
                base.tokenMap.delete(key);
            }
            if (base.cmdMap.has(key)) {
                base.cmdMap.delete(key);
            }
        }
        sockets.tcp.addEventListener("close", clear);
        sockets.tcp.addEventListener("error", clear);
    }
    /**
     * state:开关状态
     * @param {string} event state
     * @param {function({ip:string,port:number,data:boolean})} handler 
     */
    addEventListener(event, handler) {
        if (!convert.isNull(event) && typeof handler == "function") {
            if (this.eventMap.has(event)) {
                this.eventMap.set(event, this.eventMap.get(event).concat([handler]));
            }
            else {
                this.eventMap.set(event, [handler]);
            }
        }
    }
    /**
     * @param {string} event 
     * @param {object} e 
     */
    dispatchEvent(event, e) {
        if (!convert.isNull(event)) {
            if (this.eventMap.has(event)) {
                const handlers = this.eventMap.get(event);
                for (var i = 0; i < handlers.length; i++) {
                    var h = handlers[i];
                    if (h(e) == true)//返回true阻止事件继续执行
                        break;
                }
            }
        }
    }
    send(ip, port) {
        const key = ip + ":" + port;
        if (this.cmdMap.has(key) && this.tokenMap.has(key)) {
            const temp = this.cmdMap.get(key);
            const cmd = this.tokenMap.get(key) + temp.cmd;
            sockets.tcp.send(cmd, ip, port, temp.delay);
            this.cmdMap.delete(key);
        }
    }
    invoke(d, cmd, delay) {
        const key = d.ip + ":" + d.port;
        if (this.cmdMap.has(key)) {
            console.log(`投影机[${d.ip}]有未执行指令，请稍后再试`);
            return;
        }
        if (delay > 30000)
            delay = 30000;
        //缓存指令
        this.cmdMap.set(key, { cmd: cmd, delay: delay });
        //确保已建立tcp连接
        sockets.tcp.open(d.port, d.ip);
    }
    on(d, delay) {
        this.invoke(d, "on", delay);
    }
    off(d, delay) {
        this.invoke(d, "off", delay);
    }
    refresh(d) {
        this.invoke(d, "state", delay);
    }
}

const managers = {
    computer: new ComputerManager(),
    pjlink: new PJLinkManager(),
    jyboard: new JYBoardManager()
};